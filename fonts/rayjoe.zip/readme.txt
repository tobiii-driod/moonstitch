Rayjoe is a font created by Joe Chau in 2014.

This font is free for personal use, however, you may not:


1. Sell this font without permission.

2. Redistribute this font without permission.


If you want to use for any commercial use, please notice me and pay usd $1 to the following paypal and email account:

ankychoi2@msn.com


You can also donate freely if you like it :)


Thank you!